<?php
/**
    Template Name:index
 */
?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"/>
    <meta name="apple-mobile-web-app-capable" content="yes"/>
    <meta name="apple-mobile-web-app-status-bar-style" content="black"/>
    <meta name="format-detection" content="telephone=no"/>     
    <title>首页</title>
    <!--CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo CURRENT_TEMPLATE_DIR.'/css/pure-min.css' ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo CURRENT_TEMPLATE_DIR.'/css/dessert.css' ?>">
</head>
<body class="black_bg" ontouchstart="">
<div class="header" style="background-color:#1a1a1a;">
  <p id="home"></p>
</div>
<div class="container">
  <div class="logo">
    <img src="<?php echo CURRENT_TEMPLATE_DIR.'/images/logo1.png' ?>" width="177">
  </div>
  <div class="order">
    <a href="http://holyringcafe.gchu.cn/%E5%95%86%E5%93%81%E5%88%86%E7%B1%BB/dessert/"><img src="<?php echo CURRENT_TEMPLATE_DIR.'/images/order_buttom.gif' ?>" width="100"></a>
  </div>
</div>

