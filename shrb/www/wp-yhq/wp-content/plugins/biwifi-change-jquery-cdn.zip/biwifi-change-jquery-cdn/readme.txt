=== Change jQuery CDN ===
Contributors: wxx
Tags: jQuery CDN, Google, Woocommerce
Requires at least: 3.5
Tested up to: 3.9.1
Stable tag: 1.0

Change enqueuing of jQuery ui css used by woocommerce from Google to Microsoft.

== Description ==

