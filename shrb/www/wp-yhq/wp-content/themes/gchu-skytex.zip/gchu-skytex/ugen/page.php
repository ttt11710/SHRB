<?php include_once('header.php');?>
<?php the_content(); ?>
	asdfsgaasg